<?php
   require "chat_app.php";
   require "email.php";
   require "sms.php";
   require "whatsapp.php";

 #creating objects of the classes
    $whatapp_obj=new whatsapp();
    $SMS_obj=new SMS();
    $Email_obj=new Email();
    echo "============== MESSAGING SYSYTEMS ===============\n";
    # accessing the methods from the classes 
    $whatapp_obj->send_message("7095790619","Hey...!");
    echo "\n---------------------------------------------------------\n";
    $whatapp_obj->receive_message("628156484","Hey...!");
    echo "\n====================================================\n";
    $SMS_obj->send_message("6281256484","Hii..!chinmaya");
    echo "\n---------------------------------------------------------\n";
    $SMS_obj->receive_message("7095790619","Hii..!chinmaya");
    echo "\n====================================================\n";
    $Email_obj->send_message("ganjichinmaya01@gmail.com","Dear chinmaya,\n\t please send the project status.");
    echo "\n---------------------------------------------------------\n";
    $Email_obj->receive_message("chinmaya@mindtree.com","Dear chinmaya, \n\t please send the project status.");
?>
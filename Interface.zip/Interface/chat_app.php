<?php
    # creating an interface
    interface chat_app{
        public function send_message($recepient,$message);
        public function receive_message($sender,$message);
    }
?>
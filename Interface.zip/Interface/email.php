<?php
# implementing the chatApp interface in Email class
    class Email implements chat_app{
        private $subject;

        # Additional function other than functions in inteface 
        public function get_subject(){
            $this->subject= readline("Enter subject of the mail : ");
            return $this->subject;
        }

        #implementing send_message function
        public function send_message($recepient_mail,$message){
            $this->subject=$this->get_subject();
            echo "Sending Message (Email) To : $recepient_mail";
            echo "\nSubject : $this->subject \nMessage :$message";
        }

        #implementing receive_message function
        public function receive_message($sender_mail,$message){
            echo "Received from (Email) : $sender_mail\nSubject : $this->subject\nMessage: $message";
        }
        
    }
    
?>
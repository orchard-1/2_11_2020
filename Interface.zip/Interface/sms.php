  <?php
    # implementing the chatApp interface in SMS class
    class SMS implements chat_app{
        
        #implementing send_message function
        public function send_message($mobile_number,$message){
            echo "Sending Message (SMS) : $message \nTo : $mobile_number";
        }

        #implementing receive_message function
        public function receive_message($sender,$message){
            echo "Received from (SMS) : $sender\nMessage: $message";
        }
    }
?>
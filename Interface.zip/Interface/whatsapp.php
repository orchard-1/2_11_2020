<?php
# implementing the chatApp interface in whatsapp class
    class whatsapp implements chat_app{

        #implementing send_message function
        public function send_message($whatsapp_number,$message){
            echo "Sending Whatsapp Message : $message \nTo : $whatsapp_number";
        }

        #implementing receive_message function
        public function receive_message($sender,$message){
            echo "Received from : $sender\nMessage: $message";
        }
    }
?>
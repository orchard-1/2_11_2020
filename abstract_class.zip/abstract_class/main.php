<?php

    require "sport.php";
    require "marathon.php";
    require "swimming.php";
    # driver block
        $swim_obj= new swimming_competiton();
        $maraton_obj=new marathon();

        $swim_obj->participate();
        $swim_obj->swim();
        $swim_obj->Location();
        echo "\n------------------------------\n";
        $maraton_obj->participate();
        $maraton_obj->run();
        $maraton_obj->cashPrice();
?>
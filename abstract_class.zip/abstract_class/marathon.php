<?php
     # extending the abstaract class sport
    class marathon extends sport{
        public function participate(){
            echo "paricipating in Marathon\n";
        }
        public function cashPrice(){
            echo "Cash price is : 1Lakh";
        }

    }

?>
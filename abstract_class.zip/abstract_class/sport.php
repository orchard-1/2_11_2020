<?php
    # creating a abstract class
    abstract class sport{
        
        # creating a abstarct function child needs to over-ride
        abstract public function participate();

        # creating normal function child need not to override
        public function run(){
            echo "Action : Running \n";
        }

        # creating normal function child need not to override
        public function swim(){
            echo "Action : Swimming \n";
        }
    }
?>
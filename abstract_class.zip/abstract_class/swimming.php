<?php
    # extending the abstaract class sport
        class swimming_competiton extends sport{
            
            # over-riding participate() from sport
            public function participate(){
                echo "\nparicipating in swimming competiton\n";
            }
            
            public function Location(){
                echo "Location : London";
            }
        }
 ?>       